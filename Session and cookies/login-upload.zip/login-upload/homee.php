<?php

session_start();
if (!isset($_SESSION["login"])) {
	header("location:login.php");
}



 ?>

<!DOCTYPE html>
<html>
<head>
	<title>home</title>
</head>
<body>
<form action="upload.php" method="post" enctype="multipart/form-data">
	<table>
		<tr>
			<td>Silahkan Upload File Anda</td>
		</tr>
		<tr>
			<td><input type="submit" name="upload" value="upload"> </td>  <td><input type="file" name="fileToUpload"></td> 
		</tr>
	</table>
</form>
</body>
</html>