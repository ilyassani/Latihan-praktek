<?php 

if (isset($_POST["upload"]))
{
	$namafile = basename($_FILES["fileToUpload"]["name"]);
	$namaSementara = $_FILES["fileToUpload"]["tmp_name"];
	$dir = "uploads/";
	$cek = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
	if ($cek !== false) {
		$fullPath = $dir.$namafile;
		$hasilupload = move_uploaded_file($namaSementara, $fullPath);
		$imageFileType = pathinfo($fullPath, PATHINFO_EXTENSION);
		if ($hasilupload) {
			echo "sukses <br/>";
			echo "link: <a href ='".$dir.$namafile."'>".$namafile."</a>";
			echo "file is an image - " .$cek['mime']. ".";
			echo "<img src='$fullPath'>";
		}else{
			echo "gagal";

		}

		}else{
			echo "not image";
		}
	}


 ?>