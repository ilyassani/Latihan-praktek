

<?php 
session_start();

if (isset($_SESSION["add"])) {
	header("location:homee.php");
}




$conn = mysqli_connect("localhost","root","","form");
if (isset($_POST["add"])) {
	$username = $_POST['Username'];
	$password = $_POST['Password'];

	$ilyas = mysqli_query($conn,"SELECT id,password FROM table_user WHERE username = '$username'");
	if (mysqli_num_rows($ilyas)) {
		$row = mysqli_fetch_assoc($ilyas);


		if ($password === $row ['password']) {

			$_SESSION ["login"] = "login";
			$namecookis = "seroea";
			$namevalue = $_SESSION ["login"];
			setcookie($namecookis,$namevalue, time()+ (86400*30));
			header("location:homee.php");
		}else{
			echo "password yg anda masukkan salah";
		}
		

	
	
		}
}






 ?>


<!DOCTYPE html>
<html>
<head>
	<title>
		login
	</title>
</head>
<body>
	<form action="" method="post">
	<table>
		<tr>
	<td>USERNAME </td><td>:</td> <td><input type="username " name="Username" placeholder="username"></td>
		</tr>

		<tr>
			<td> PASSWORD </td> <td>: </td> <td><input type="Password" name="Password" placeholder="password"></td>
		</tr>
		<tr>
			<td><button name="add">	Login </button></td>
		</tr>




	</table>

	</form>

</body>
</html>